package models;

import java.util.Date;

public class Compte {
    private String numero;
    private String cinProprietaire;
    private double solde;
    private Date dateOuverture;
    private String typeCompte; // "courant" or "epargne"
    

    // Constructor
    public Compte(String numero, String cinProprietaire, double solde, Date dateOuverture, String typeCompte) {
        this.numero = numero;
        this.cinProprietaire = cinProprietaire;
        this.solde = solde;
        this.dateOuverture = dateOuverture;
        this.typeCompte = typeCompte;
    }

    // Getters and Setters
    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getCinProprietaire() {
        return cinProprietaire;
    }

    public void setCinProprietaire(String cinProprietaire) {
        this.cinProprietaire = cinProprietaire;
    }

    public double getSolde() {
        return solde;
    }

    public void setSolde(double solde) {
        this.solde = solde;
    }

    public Date getDateOuverture() {
        return dateOuverture;
    }

    public void setDateOuverture(Date dateOuverture) {
        this.dateOuverture = dateOuverture;
    }

    public String getTypeCompte() {
        return typeCompte;
    }

    public void setTypeCompte(String typeCompte) {
        this.typeCompte = typeCompte;
    }

    

    @Override
    public String toString() {
        return "Compte{" +
                "numero='" + numero + '\'' +
                ", cinProprietaire='" + cinProprietaire + '\'' +
                ", solde=" + solde +
                ", dateOuverture=" + dateOuverture +
                ", typeCompte='" + typeCompte + '\'' +
                
                '}';
    }
}