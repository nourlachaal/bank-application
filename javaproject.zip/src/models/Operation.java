package models;

public class Operation {
    private String type; // "retrait", "versement", or "virement"
    private String compteSource;
    private String compteDestination;
    private double montant;

    // Constructor
    public Operation(String type, String compteSource, String compteDestination, double montant) {
        this.type = type;
        this.compteSource = compteSource;
        this.compteDestination = compteDestination;
        this.montant = montant;
    }

    // Getters and Setters
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCompteSource() {
        return compteSource;
    }

    public void setCompteSource(String compteSource) {
        this.compteSource = compteSource;
    }

    public String getCompteDestination() {
        return compteDestination;
    }

    public void setCompteDestination(String compteDestination) {
        this.compteDestination = compteDestination;
    }

    public double getMontant() {
        return montant;
    }

    public void setMontant(double montant) {
        this.montant = montant;
    }

    @Override
    public String toString() {
        return "Operation{" +
                "type='" + type + '\'' +
                ", compteSource='" + compteSource + '\'' +
                ", compteDestination='" + compteDestination + '\'' +
                ", montant=" + montant +
                '}';
    }
}