package views;

import models.Client;
import services.ClientService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddClientFrame extends JDialog {
    private JTextField cinField;
    private JTextField nomField;
    private JTextField prenomField;
    private JTextField telephoneField;
    private ClientService clientService;

    public AddClientFrame(JFrame parent) {
        super(parent, "Créer un compte client", true);
        this.clientService = new ClientService();
        
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20); // Spacing between components
        gbc.fill = GridBagConstraints.HORIZONTAL; // Fill horizontally

        // Title
        JLabel titleLabel = new JLabel("Créer un Compte Client");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(34, 67, 240)); // Title color
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2; // Take full width
        add(titleLabel, gbc);

        // CIN Field
        gbc.gridwidth = 1; // Reset to one column
        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("CIN:"), gbc);
        
        cinField = new JTextField();
        gbc.gridx = 1; add(cinField, gbc);

        // Name Field
        gbc.gridx = 0; gbc.gridy = 2;
        add(new JLabel("Nom:"), gbc);
        
        nomField = new JTextField();
        gbc.gridx = 1; add(nomField, gbc);

        // Surname Field
        gbc.gridx = 0; gbc.gridy = 3;
        add(new JLabel("Prénom:"), gbc);
        
        prenomField = new JTextField();
        gbc.gridx = 1; add(prenomField, gbc);

        // Phone Field
        gbc.gridx = 0; gbc.gridy = 4;
        add(new JLabel("Téléphone:"), gbc);
        
        telephoneField = new JTextField();
        gbc.gridx = 1; add(telephoneField, gbc);

       // Create Button
       JButton addButton = new JButton("Créer");
       addButton.setBackground(new Color(34, 67, 240)); // Blue color
       addButton.setForeground(Color.WHITE);
       addButton.setFont(new Font("Arial", Font.BOLD, 18));
       
       addButton.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               if (cinField.getText().isEmpty() || nomField.getText().isEmpty() ||
                   prenomField.getText().isEmpty() || telephoneField.getText().isEmpty()) {
                   JOptionPane.showMessageDialog(AddClientFrame.this,
                           "Tous les champs doivent être remplis.", "Erreur",
                           JOptionPane.ERROR_MESSAGE);
                   return;
               }

               Client client = new Client(
                       cinField.getText(),
                       nomField.getText(),
                       prenomField.getText(),
                       telephoneField.getText(),
                       "defaultPassword" // Handle password appropriately if needed.
               );

               if (clientService.addClient(client)) {
                   JOptionPane.showMessageDialog(AddClientFrame.this,
                           "Client ajouté avec succès !");
                   dispose(); // Close the dialog
               } else {
                   JOptionPane.showMessageDialog(AddClientFrame.this,
                           "Erreur lors de l'ajout du client.", "Erreur",
                           JOptionPane.ERROR_MESSAGE);
               }
           }
       });

       gbc.gridwidth = 2; // Take full width for the button
       gbc.gridx = 0; gbc.gridy = 5;
       add(addButton, gbc);

       setSize(800, 500); // Window size
       setLocationRelativeTo(parent); // Center the window relative to parent
   }
}
