package views;

import models.Compte;
import services.CompteService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

public class AddAccountDialog extends JDialog {
    private JTextField numeroField;
    private JTextField cinField;
    private JTextField soldeField;
    private JTextField typeCompteField;
    private CompteService compteService; // Service for managing accounts
    private ClientAccountsDashboard managementPanel; // Reference to the management panel

    public AddAccountDialog(ClientAccountsDashboard parent) {
        super(parent, "Ajouter un Compte", true);
        this.managementPanel = parent; // Assigning the management panel reference
        this.compteService = new CompteService(); // Initialize the account service

        setLayout(new GridLayout(5, 2));

        add(new JLabel("Numéro de Compte:"));
        numeroField = new JTextField();
        add(numeroField);

        add(new JLabel("CIN Propriétaire:"));
        cinField = new JTextField();
        add(cinField);

        add(new JLabel("Solde:"));
        soldeField = new JTextField();
        add(soldeField);

        add(new JLabel("Type de Compte:"));
        typeCompteField = new JTextField();
        add(typeCompteField);

        JButton addButton = new JButton("Ajouter");

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String numero = numeroField.getText().trim();
                String cin = cinField.getText().trim();
                double solde;
                String typeCompte = typeCompteField.getText().trim();

                try {
                    solde = Double.parseDouble(soldeField.getText().trim());
                    Compte newAccount = new Compte(numero, cin, solde, new Date(), typeCompte);

                    // Add account to database
                    if (compteService.addCompte(newAccount)) {
                        managementPanel.addCompte(newAccount); // Refresh the table after adding
                        dispose(); // Close the dialog
                    } else {
                        JOptionPane.showMessageDialog(AddAccountDialog.this,
                                "Erreur lors de l'ajout du compte.", "Erreur", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(AddAccountDialog.this,
                            "Veuillez entrer un solde valide.", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        add(addButton);

        setSize(300, 200); // Set dialog size
        setLocationRelativeTo(parent); // Center relative to parent
    }
}
