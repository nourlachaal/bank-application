package views;

import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import models.Client;
import services.ClientService;

public class ClientManagementPanel extends JPanel {
    private JTable clientTable;
    private ClientService clientService;

    public ClientManagementPanel() {
       this.clientService = new ClientService(); // Initialize service
       setLayout(new BorderLayout());

       String[] columnNames = {"CIN", "Nom", "Prénom", "Téléphone"};
       DefaultTableModel model = new DefaultTableModel(columnNames, 0);
       
       clientTable = new JTable(model);
       
       loadClients(); // Load clients into table

       JScrollPane scrollPane = new JScrollPane(clientTable);
       add(scrollPane, BorderLayout.CENTER);

       JPanel buttonPanel = new JPanel();

       JButton addButton = new JButton("Ajouter Client");
       JButton updateButton = new JButton("Modifier Client");
       JButton deleteButton = new JButton("Supprimer Client");

       buttonPanel.add(addButton);
       buttonPanel.add(updateButton);
       buttonPanel.add(deleteButton);

       add(buttonPanel, BorderLayout.SOUTH);

       addButton.addActionListener(e -> openAddClientDialog());
       updateButton.addActionListener(e -> updateSelectedClient());
       deleteButton.addActionListener(e -> deleteSelectedClient());
   }

   private void loadClients() {
       List<Client> clients = clientService.getAllClients();
       DefaultTableModel model = (DefaultTableModel) clientTable.getModel();

       model.setRowCount(0); // Clear existing rows
       for (Client client : clients) {
           model.addRow(new Object[]{
               client.getCin(),
               client.getNom(),
               client.getPrenom(),
               client.getTelephone()
           });
       }
   }

   private void openAddClientDialog() {
       AddClientFrame addClientFrame = new AddClientFrame((JFrame) SwingUtilities.getWindowAncestor(this));
       addClientFrame.setVisible(true);
   }

   private void updateSelectedClient() {
       int selectedRow = clientTable.getSelectedRow();
       if (selectedRow != -1) {
           String cinToEdit = (String) clientTable.getValueAt(selectedRow, 0);
           Client clientToEdit = clientService.findClientByCin(cinToEdit); 
           if (clientToEdit != null) {
               EditClientFrame editClientFrame = new EditClientFrame(this, clientToEdit); 
               editClientFrame.setVisible(true); 
           } else {
               JOptionPane.showMessageDialog(this,
                       "Erreur lors de la récupération du client.", "Erreur",
                       JOptionPane.ERROR_MESSAGE);
           }
       } else {
           JOptionPane.showMessageDialog(this,
                   "Veuillez sélectionner un client à modifier.", "Avertissement",
                   JOptionPane.WARNING_MESSAGE);
       }
   }

   private void deleteSelectedClient() {
       int selectedRow = clientTable.getSelectedRow();
       if (selectedRow != -1) { 
           String cinToDelete = (String) clientTable.getValueAt(selectedRow, 0);
           int confirm = JOptionPane.showConfirmDialog(this,
                   "Êtes-vous sûr de vouloir supprimer le client avec CIN: " + cinToDelete + "?",
                   "Confirmation de suppression",
                   JOptionPane.YES_NO_OPTION);

           if (confirm == JOptionPane.YES_OPTION) {
               if (clientService.deleteClient(cinToDelete)) {
                   JOptionPane.showMessageDialog(this,
                           "Client supprimé avec succès !");
                   loadClients(); // Refresh the table
               } else {
                   JOptionPane.showMessageDialog(this,
                           "Erreur lors de la suppression du client.", "Erreur",
                           JOptionPane.ERROR_MESSAGE);
               }
           }
       } else {
           JOptionPane.showMessageDialog(this,
                   "Veuillez sélectionner un client à supprimer.", "Avertissement",
                   JOptionPane.WARNING_MESSAGE);
       }
   }
}
