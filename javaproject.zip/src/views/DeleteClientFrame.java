package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import services.ClientService;

public class DeleteClientFrame extends JDialog {
    private ClientService clientService; // Service pour gérer les clients

    public DeleteClientFrame(JFrame parent, String cin) {
        super(parent, "Supprimer un Client", true);
        
        this.clientService = new ClientService(); // Initialiser le service des clients
        
        setLayout(new FlowLayout());
        
        JLabel confirmLabel = new JLabel("Voulez-vous vraiment supprimer le client avec CIN : " + cin + " ?");
        
        JButton deleteButton = new JButton("Supprimer");
        
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (clientService.deleteClient(cin)) {
                    JOptionPane.showMessageDialog(DeleteClientFrame.this, "Client supprimé avec succès !");
                    dispose(); // Fermez la fenêtre après suppression
                } else {
                    JOptionPane.showMessageDialog(DeleteClientFrame.this, "Erreur lors de la suppression du client.", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        JButton cancelButton = new JButton("Annuler");
        
        cancelButton.addActionListener(e -> dispose()); // Fermer sans supprimer
        
        add(confirmLabel);
        add(deleteButton);
        add(cancelButton);
        
        setSize(300, 150);
        setLocationRelativeTo(parent); // Centrer par rapport à la fenêtre principale
    }
}