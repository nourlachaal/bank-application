package views;

import models.Compte;
import services.CompteService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ClientAccountsDashboard extends JFrame {
    private JTable compteTable; // Table for displaying accounts
    private List<Compte> comptes; // List of accounts

    public ClientAccountsDashboard() {
        this.comptes = new ArrayList<>(); // Initialize account list
        setTitle("Tableau de Bord des Comptes");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window

        String[] columnNames = { "Numéro", "CIN Propriétaire", "Solde", "Date d'Ouverture", "Type de Compte" };
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        compteTable = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(compteTable);
        add(scrollPane, BorderLayout.CENTER);

        JButton addButton = new JButton("Ajouter Compte");

        addButton.addActionListener(e -> openAddCompteDialog());

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    public void openAddCompteDialog() {
        AddAccountDialog addAccountDialog = new AddAccountDialog(this); // Pass current instance as dashboard
        addAccountDialog.setVisible(true);
    }

    public void addCompte(Compte compte) {
        DefaultTableModel model = (DefaultTableModel) compteTable.getModel();
        model.addRow(new Object[] { compte.getNumero(), compte.getCinProprietaire(),
                compte.getSolde(), compte.getDateOuverture(),
                compte.getTypeCompte() });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ClientAccountsDashboard dashboard = new ClientAccountsDashboard();
            dashboard.setVisible(true);
        });
    }
}
