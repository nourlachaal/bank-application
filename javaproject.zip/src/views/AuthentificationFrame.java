package views;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import models.Compte;
import services.CompteService;

public class AuthentificationFrame extends JFrame {
    public AuthentificationFrame() {
        setTitle("Bienvenue dans notre Application Bancaire");
        setSize(1000, 700); // Taille de la fenêtre
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centre la fenêtre

        // Créer un panneau principal
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Titre
        JLabel titleLabel = new JLabel("Veuillez entrer vos informations");
        titleLabel.setForeground(new Color(34, 67, 240)); // Couleur du titre
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(20, 0, 20, 0);
        gbc.gridwidth = 5; // Prendre toute la largeur
        panel.add(titleLabel, gbc);

        // Champ Nom
        gbc.gridwidth = 1; // Réinitialiser à une seule colonne
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Nom:"), gbc);

        JTextField nameField = new JTextField(20);
        gbc.gridx = 3;
        panel.add(nameField, gbc);
        // Champ CIN
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("CIN:"), gbc);

        JTextField cinField = new JTextField(20);
        gbc.gridx = 3;
        panel.add(cinField, gbc);
        // Bouton Se Connecter
        JButton loginButton = new JButton("Se connecter");
        loginButton.setBackground(new Color(34, 67, 240)); // Couleur bleue
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Arial", Font.BOLD, 20));

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String cin = cinField.getText();

                // Logique d'authentification ici (à implémenter)
                if (authenticateClient(cin, name)) { // Remplacez par votre logique d'authentification réelle
                    JOptionPane.showMessageDialog(AuthentificationFrame.this, "Connexion réussie !");

                    // Ouvrir la fenêtre pour ajouter un compte après connexion réussie
                    AddCompteFrame addCompteFrame = new AddCompteFrame(AuthentificationFrame.this);
                    addCompteFrame.setVisible(true);
                    dispose(); // Ferme l'interface d'authentification
                } else {
                    JOptionPane.showMessageDialog(AuthentificationFrame.this, "Identifiants incorrects.", "Erreur",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        gbc.gridwidth = 6; // Prendre toute la largeur pour le bouton
        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(loginButton, gbc);

        // Bouton Accéder au Tableau de Bord Administrateur
        JButton adminDashboardButton = new JButton("Admin ");
        adminDashboardButton.setBackground(new Color(34, 67, 240));
        adminDashboardButton.setForeground(Color.WHITE);
        adminDashboardButton.setFont(new Font("Arial", Font.BOLD, 20));

        adminDashboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AdminLoginFrame adminLoginFrame = new AdminLoginFrame(AuthentificationFrame.this);
                adminLoginFrame.setVisible(true);
            }
        });

        gbc.gridy = 15;
        panel.add(adminDashboardButton, gbc);

        // Ajouter le panneau à la fenêtre principale
        add(panel);
    }

    private boolean authenticateClient(String cin, String motDePasse) {
        // Implémentez votre logique d'authentification ici.
        return "clientCIN".equals(cin) && "password".equals(motDePasse); // Remplacez par votre logique réelle
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AuthentificationFrame frame = new AuthentificationFrame();
            frame.setVisible(true);
        });
    }

}