package views;

import java.awt.*;
import javax.swing.*;
import services.OperationService;

public class OperationManagementPanel extends JPanel {

    private JTextField accountNumberField;
    private JTextField amountField;
    private OperationService operationService;

    public OperationManagementPanel() {
       this.operationService = new OperationService(); // Initialize service

       setLayout(new GridBagLayout());
       GridBagConstraints gbc = new GridBagConstraints();

       JLabel titleLabel = new JLabel("Gestion des Opérations");
       titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
       
       gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth=2; 
       gbc.insets=new Insets(20,20,20,20); 
       add(titleLabel, gbc);

       gbc.gridwidth=1; 
       gbc.gridx=0; gbc.gridy=1; 
       add(new JLabel("Numéro de Compte:"), gbc);

       accountNumberField=new JTextField(15); 
       gbc.gridx=1; 
       add(accountNumberField,gbc);

       gbc.gridx=0; gbc.gridy=2; 
       add(new JLabel("Montant:"),gbc);

       amountField=new JTextField(15); 
       gbc.gridx=1; 
       add(amountField,gbc);

      JButton depositButton=new JButton("Déposer"); 
      depositButton.addActionListener(e->{
          String accountNumber=accountNumberField.getText(); 
          double amount=Double.parseDouble(amountField.getText());
          if(operationService.deposit(accountNumber,amount)){
              JOptionPane.showMessageDialog(OperationManagementPanel.this,"Dépôt effectué avec succès !");
          }else{
              JOptionPane.showMessageDialog(OperationManagementPanel.this,"Erreur lors du dépôt.","Erreur",JOptionPane.ERROR_MESSAGE); 
          }
      });

      gbc.gridx=0; gbc.gridy=3; 
      add(depositButton,gbc);

      JButton withdrawButton=new JButton("Retirer"); 
      withdrawButton.addActionListener(e->{
          String accountNumber=accountNumberField.getText(); 
          double amount=Double.parseDouble(amountField.getText());
          if(operationService.withdraw(accountNumber,amount)){
              JOptionPane.showMessageDialog(OperationManagementPanel.this,"Retrait effectué avec succès !");
          }else{
              JOptionPane.showMessageDialog(OperationManagementPanel.this,"Erreur lors du retrait.","Erreur",JOptionPane.ERROR_MESSAGE); 
          }
      });

      gbc.gridx=1; 
      add(withdrawButton,gbc);

      JButton transferButton=new JButton("Transférer"); 
      transferButton.addActionListener(e->{
          String sourceAccount=accountNumberField.getText(); 
          String destinationAccount=JOptionPane.showInputDialog(OperationManagementPanel.this,"Numéro de compte destinataire:");
          double amount=Double.parseDouble(amountField.getText());

          if(operationService.transfer(sourceAccount,destinationAccount,amount)){
              JOptionPane.showMessageDialog(OperationManagementPanel.this,"Transfert effectué avec succès !");
          }else{
              JOptionPane.showMessageDialog(OperationManagementPanel.this,"Erreur lors du transfert.","Erreur",JOptionPane.ERROR_MESSAGE); 
          }
      });

      gbc.gridx=0; gbc.gridy=4; 
      add(transferButton,gbc);
   }
}
