package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import services.CompteService;

public class DeleteCompteFrame extends JDialog {
    private CompteService compteService; 

    public DeleteCompteFrame(JFrame parent, String numero) {
      super(parent, "Supprimer un Compte", true);
      
      this.compteService = new CompteService(); 
      
      setLayout(new FlowLayout());
      
      JLabel confirmLabel = new JLabel("Voulez-vous vraiment supprimer le compte numéro : " + numero + " ?");
      
      JButton deleteButton = new JButton("Supprimer");
      
      deleteButton.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
              if (compteService.deleteCompte(numero)) {
                  JOptionPane.showMessageDialog(DeleteCompteFrame.this, "Compte supprimé avec succès !");
                  dispose(); 
              } else {
                  JOptionPane.showMessageDialog(DeleteCompteFrame.this, "Erreur lors de la suppression du compte.", "Erreur", JOptionPane.ERROR_MESSAGE);
              }
          }
      });
      
      JButton cancelButton = new JButton("Annuler");
      
      cancelButton.addActionListener(e -> dispose()); 
      
      add(confirmLabel);
      add(deleteButton);
      add(cancelButton);
      
      setSize(300, 150);
      setLocationRelativeTo(parent); 
   }
}