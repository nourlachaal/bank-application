package views;

import javax.swing.*;

public class AdminDashboard extends JFrame {
    public AdminDashboard() {
        setTitle("Tableau de Bord Administrateur");
        setSize(1000, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Add management panels
        tabbedPane.addTab("Gestion des Clients", new ClientManagementPanel());
        tabbedPane.addTab("Gestion des Comptes", new CompteManagementPanel());
        tabbedPane.addTab("Opérations", new OperationManagementPanel());

        add(tabbedPane);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AdminDashboard dashboard = new AdminDashboard();
            dashboard.setVisible(true);
        });
    }
}
