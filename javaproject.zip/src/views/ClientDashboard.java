package views;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import models.Client;

public class ClientDashboard extends JFrame {
    private double balance; // Montant d'argent du client
    private JTextField amountField; // Champ pour le montant à ajouter ou retirer
    private JTextField transferAccountField; // Champ pour le numéro de compte à transférer
    private JTextField transferAmountField; // Champ pour le montant à transférer
    private JTable transactionHistoryTable; // Table pour afficher l'historique des transactions

    public ClientDashboard(String clientName, double initialBalance) {
        this.balance = initialBalance; // Initialiser le solde
        setTitle("Tableau de Bord du Client - " + clientName);
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centre la fenêtre

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        // Panneau pour afficher le solde
        JPanel balancePanel = new JPanel();
        JLabel balanceLabel = new JLabel("Solde: " + balance + " €");
        balanceLabel.setFont(new Font("Arial", Font.BOLD, 20));
        balancePanel.add(balanceLabel);
        mainPanel.add(balancePanel, BorderLayout.NORTH);

        // Panneau pour les opérations financières
        JPanel operationsPanel = new JPanel();
        operationsPanel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Espacement entre les composants

        // Ajouter de l'argent
        gbc.gridx = 0;
        gbc.gridy = 0;
        operationsPanel.add(new JLabel("Montant à Ajouter:"), gbc);

        amountField = new JTextField(15);
        gbc.gridx = 1;
        operationsPanel.add(amountField, gbc);

        JButton addButton = new JButton("Ajouter de l'Argent");
        addButton.addActionListener(e -> handleAddMoney(balanceLabel));

        gbc.gridx = 2;
        operationsPanel.add(addButton, gbc);

        // Retirer de l'argent
        gbc.gridx = 0;
        gbc.gridy = 1;
        operationsPanel.add(new JLabel("Montant à Retirer:"), gbc);

        JTextField withdrawField = new JTextField(15);
        gbc.gridx = 1;
        operationsPanel.add(withdrawField, gbc);

        JButton withdrawButton = new JButton("Retirer de l'Argent");
        withdrawButton.addActionListener(e -> handleWithdraw(withdrawField, balanceLabel));

        gbc.gridx = 2;
        operationsPanel.add(withdrawButton, gbc);

        // Transférer de l'argent
        setupTransferSection(operationsPanel, gbc);

        mainPanel.add(operationsPanel, BorderLayout.CENTER);

        setupTransactionHistory(mainPanel);

        JButton backButton = new JButton("Retour aux Comptes");
        backButton.addActionListener(e -> dispose()); // Ferme la fenêtre actuelle
        mainPanel.add(backButton, BorderLayout.NORTH); // Ajouter le bouton en haut du panneau principal

        add(mainPanel);
    }

    private void setupTransferSection(JPanel panel, GridBagConstraints gbc) {
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Transférer vers le numéro de compte:"), gbc);

        transferAccountField = new JTextField(15);
        gbc.gridx = 1;
        panel.add(transferAccountField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Montant à Transférer:"), gbc);

        transferAmountField = new JTextField(15);
        gbc.gridx = 1;
        panel.add(transferAmountField, gbc);

        JButton transferButton = new JButton("Transférer");
        transferButton.addActionListener(e -> handleTransfer());

        gbc.gridx = 2;
        panel.add(transferButton, gbc);
    }

    private void handleAddMoney(JLabel balanceLabel) {
        try {
            double amountToAdd = Double.parseDouble(amountField.getText());
            if (amountToAdd > 0) {
                balance += amountToAdd;
                balanceLabel.setText("Solde: " + balance + " €");
                amountField.setText(""); // Réinitialiser le champ
            } else {
                showErrorMessage("Veuillez entrer un montant positif.");
            }
        } catch (NumberFormatException ex) {
            showErrorMessage("Veuillez entrer un montant valide.");
        }
    }

    private void handleWithdraw(JTextField withdrawField, JLabel balanceLabel) {
        try {
            double amountToWithdraw = Double.parseDouble(withdrawField.getText());
            if (amountToWithdraw > 0 && amountToWithdraw <= balance) {
                balance -= amountToWithdraw;
                balanceLabel.setText("Solde: " + balance + " €");
                withdrawField.setText(""); // Réinitialiser le champ
            } else {
                showErrorMessage("Montant invalide ou insuffisant.");
            }
        } catch (NumberFormatException ex) {
            showErrorMessage("Veuillez entrer un montant valide.");
        }
    }

    private void handleTransfer() {
        String accountNumberToTransfer = transferAccountField.getText();
        try {
            double amountToTransfer = Double.parseDouble(transferAmountField.getText());
            if (amountToTransfer > 0 && amountToTransfer <= balance) {
                balance -= amountToTransfer;
                transferAmountField.setText(""); // Réinitialiser le champ
                transferAccountField.setText(""); // Réinitialiser le champ
                addTransaction(accountNumberToTransfer, amountToTransfer); // Logique pour ajouter une transaction à
                                                                           // l'historique
            } else {
                showErrorMessage("Montant invalide ou insuffisant.");
            }
        } catch (NumberFormatException ex) {
            showErrorMessage("Veuillez entrer un montant valide.");
        }
    }

    private void setupTransactionHistory(JPanel mainPanel) {
        String[] columnNames = { "Date", "Numéro de Compte", "Montant", "Type" };
        DefaultTableModel transactionModel = new DefaultTableModel(columnNames, 0);

        transactionHistoryTable = new JTable(transactionModel);
        JScrollPane transactionScrollPane = new JScrollPane(transactionHistoryTable);

        mainPanel.add(transactionScrollPane, BorderLayout.SOUTH); // Historique des transactions
    }

    private void addTransaction(String accountNumber, double amount) {
        DefaultTableModel model = (DefaultTableModel) transactionHistoryTable.getModel();
        model.addRow(new Object[] { new Date(), accountNumber, amount, "Transfert" });
    }

    private void showErrorMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Erreur", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ClientDashboard dashboard = new ClientDashboard("Client Name", 1000.00);
            dashboard.setVisible(true);
        });
    }
}
