package views;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import models.Compte;
import services.CompteService;

public class AddCompteFrame extends JDialog {
    private JTextField numeroField;
    private JTextField cinProprietaireField;
    private JTextField soldeField;
    private JTextField typeCompteField;
    private CompteService compteService; // Service pour gérer les comptes

    public AddCompteFrame(Frame parent) {
        super(parent, "Ajouter un Compte", true);
        this.compteService = new CompteService(); // Initialiser le service des comptes
        setLayout(new GridLayout(6, 2));

        // Champs de saisie
        add(new JLabel("Numéro de Compte:"));
        numeroField = new JTextField();
        add(numeroField);

        add(new JLabel("CIN Propriétaire:"));
        cinProprietaireField = new JTextField();
        add(cinProprietaireField);

        add(new JLabel("Solde:"));
        soldeField = new JTextField();
        add(soldeField);

        add(new JLabel("Type de Compte:"));
        typeCompteField = new JTextField();
        add(typeCompteField);

       // Ajouter un bouton pour ajouter le compte
       JButton addButton = new JButton("Ajouter");
       addButton.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               Compte compte = new Compte(
                       numeroField.getText(),
                       cinProprietaireField.getText(),
                       Double.parseDouble(soldeField.getText()),
                       new java.util.Date(), // Date d'ouverture (peut être modifiée)
                       typeCompteField.getText()
               );

               if (compteService.addCompte(compte)) {
                   JOptionPane.showMessageDialog(AddCompteFrame.this, "Compte ajouté avec succès !");
                   dispose(); 
               } else {
                   JOptionPane.showMessageDialog(AddCompteFrame.this, "Erreur lors de l'ajout du compte.", "Erreur", JOptionPane.ERROR_MESSAGE);
               }
           }
       });

       // Ajouter le bouton à la fenêtre
       add(addButton);

       // Configuration de la fenêtre
       setSize(300, 250);
       setLocationRelativeTo(null); 
   }

    public AddCompteFrame(CompteManagementPanel compteManagementPanel) {
        //TODO Auto-generated constructor stub
    }
}
