package views;

import services.AdminService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminLoginFrame extends JDialog {
    private AdminService adminService; // Service for managing admins

    public AdminLoginFrame(JFrame parent) {
        super(parent, "Connexion Administrateur", true);
        this.adminService = new AdminService(); // Initialize the admin service

        setSize(400, 300);
        setLocationRelativeTo(parent); // Center the window relative to parent

        // Create main panel
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        
        // Title
        JLabel titleLabel = new JLabel("Connexion Administrateur");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2; // Take full width
        panel.add(titleLabel, gbc);

        // ID Field
        gbc.gridwidth = 1; // Reset to one column
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("ID:"), gbc);
        
        JTextField idField = new JTextField(20);
        gbc.gridx = 1; panel.add(idField, gbc);

        // Password Field
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Mot de passe:"), gbc);
        
        JPasswordField passwordField = new JPasswordField(20);
        gbc.gridx = 1; panel.add(passwordField, gbc);

        // Login Button
        JButton loginButton = new JButton("Se connecter");
        
         loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = idField.getText().trim();
                String password = new String(passwordField.getPassword()).trim();
                
                if (adminService.authenticateAdmin(id, password)) { 
                    JOptionPane.showMessageDialog(AdminLoginFrame.this, "Connexion réussie !");
                    dispose(); // Close the login window
                    
                    // Open the admin dashboard here
                    AdminDashboard adminDashboardFrame = new AdminDashboard();
                    adminDashboardFrame.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(AdminLoginFrame.this,
                            "Identifiants incorrects.", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
         });

         gbc.gridwidth = 2; // Take full width for the button
         gbc.gridx = 0; gbc.gridy = 3;
         panel.add(loginButton, gbc);

         add(panel); // Add the main panel to the dialog
    }

    public static void main(String[] args) {
       SwingUtilities.invokeLater(() -> {
           JFrame frame = new JFrame(); // Create a dummy frame to pass as parent
           AdminLoginFrame adminLoginFrame = new AdminLoginFrame(frame);
           adminLoginFrame.setVisible(true);
       });
    }
}
