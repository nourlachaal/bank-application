package views;

import models.Client;
import services.ClientService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditClientFrame extends JDialog {
    private JTextField cinField;
    private JTextField nomField;
    private JTextField prenomField;
    private JTextField telephoneField;
    private ClientService clientService; // Service for managing clients
    private String originalCin; // To keep the original CIN for updating

    public EditClientFrame(ClientManagementPanel parent, Client client) {
        super();
        this.clientService = new ClientService(); // Initialize the client service
        this.originalCin = client.getCin(); // Keep the original CIN for the update
        
        setLayout(new GridLayout(5, 2));

        // Input fields
        add(new JLabel("CIN:"));
        cinField = new JTextField(client.getCin());
        add(cinField);

        add(new JLabel("Nom:"));
        nomField = new JTextField(client.getNom());
        add(nomField);

        add(new JLabel("Prénom:"));
        prenomField = new JTextField(client.getPrenom());
        add(prenomField);

        add(new JLabel("Téléphone:"));
        telephoneField = new JTextField(client.getTelephone());
        add(telephoneField);

        // Button to update client
        JButton editButton = new JButton("Modifier");
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create a new Client object with updated values
                Client updatedClient = new Client(
                        cinField.getText(),
                        nomField.getText(),
                        prenomField.getText(),
                        telephoneField.getText(),
                        client.getPassword() // Keep the original password or handle it appropriately
                );

                // Call the method to update the client in the database
                if (clientService.updateClient(updatedClient)) {
                    JOptionPane.showMessageDialog(EditClientFrame.this, "Client modifié avec succès !");
                    dispose(); // Close the window after modification
                } else {
                    JOptionPane.showMessageDialog(EditClientFrame.this, "Erreur lors de la modification du client.", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Add button to the frame
        add(editButton);

        // Window configuration
        setSize(300, 200);
        setLocationRelativeTo(parent); // Center relative to parent
    }
}
