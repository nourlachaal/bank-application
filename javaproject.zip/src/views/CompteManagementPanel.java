package views;

import models.Compte;
import services.CompteService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class CompteManagementPanel extends JPanel {
    private JTable compteTable;
    private CompteService compteService;

    public CompteManagementPanel() {
        this.compteService = new CompteService(); // Initialize service
        setLayout(new BorderLayout());

        // Create table model
        String[] columnNames = {"Numéro", "CIN Propriétaire", "Solde", "Date d'Ouverture", "Type de Compte"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        
        compteTable = new JTable(model);
        
        // Load accounts into table
        loadComptes();

        JScrollPane scrollPane = new JScrollPane(compteTable);
        add(scrollPane, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel();
        
        JButton addButton = new JButton("Ajouter Compte");
        JButton updateButton = new JButton("Modifier Compte");
        JButton deleteButton = new JButton("Supprimer Compte");

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        add(buttonPanel, BorderLayout.SOUTH);

       // Action listeners for buttons
       addButton.addActionListener(e -> openAddCompteDialog());
       updateButton.addActionListener(e -> updateSelectedCompte());
       deleteButton.addActionListener(e -> deleteSelectedCompte());
    }

    public void loadComptes() {
       List<Compte> comptes = compteService.getAllComptes();
       DefaultTableModel model = (DefaultTableModel) compteTable.getModel();
       
       model.setRowCount(0); // Clear existing rows
       for (Compte compte : comptes) {
           model.addRow(new Object[]{
               compte.getNumero(),
               compte.getCinProprietaire(),
               compte.getSolde(),
               compte.getDateOuverture(),
               compte.getTypeCompte()
           });
       }
   }

   private void openAddCompteDialog() {
       AddAccountDialog addAccountDialog = new AddAccountDialog((JFrame) SwingUtilities.getWindowAncestor(this), this);
       addAccountDialog.setVisible(true); 
   }

   private void updateSelectedCompte() {
       int selectedRow = compteTable.getSelectedRow();
       if (selectedRow != -1) {
           String numeroCompte = (String) compteTable.getValueAt(selectedRow, 0);

           Compte compteToEdit = compteService.findCompteByNumero(numeroCompte); 
           if (compteToEdit != null) {
               EditCompteFrame editCompteFrame = new EditCompteFrame(this, compteToEdit); 
               editCompteFrame.setVisible(true); 
           } else {
               JOptionPane.showMessageDialog(this,
                       "Erreur lors de la récupération du compte.", "Erreur",
                       JOptionPane.ERROR_MESSAGE);
           }
       } else {
           JOptionPane.showMessageDialog(this,
                   "Veuillez sélectionner un compte à modifier.", "Avertissement",
                   JOptionPane.WARNING_MESSAGE);
       }
   }

   private void deleteSelectedCompte() {
       int selectedRow = compteTable.getSelectedRow();
       if (selectedRow != -1) { 
           String numeroToDelete = (String) compteTable.getValueAt(selectedRow, 0);
           int confirm = JOptionPane.showConfirmDialog(this,
                   "Êtes-vous sûr de vouloir supprimer le compte numéro: " + numeroToDelete + "?",
                   "Confirmation de suppression",
                   JOptionPane.YES_NO_OPTION);

           if (confirm == JOptionPane.YES_OPTION) {
               if (compteService.deleteCompte(numeroToDelete)) {
                   JOptionPane.showMessageDialog(this,
                           "Compte supprimé avec succès !");
                   loadComptes(); // Refresh the table
               } else {
                   JOptionPane.showMessageDialog(this,
                           "Erreur lors de la suppression du compte.", "Erreur",
                           JOptionPane.ERROR_MESSAGE);
               }
           }
       } else {
           JOptionPane.showMessageDialog(this,
                   "Veuillez sélectionner un compte à supprimer.", "Avertissement",
                   JOptionPane.WARNING_MESSAGE);
       }
   }
}
