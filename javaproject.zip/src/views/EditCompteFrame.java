package views;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import models.Compte;
import services.CompteService;

public class EditCompteFrame extends JDialog {
    private JTextField numeroField;
    private JTextField soldeField;
    private JTextField typeCompteField;
    private CompteService compteService; 

    public EditCompteFrame(CompteManagementPanel parent, Compte compte) {
       super();
       this.compteService = new CompteService(); 
       setLayout(new GridLayout(5, 2));

       numeroField = new JTextField(compte.getNumero());
       soldeField = new JTextField(String.valueOf(compte.getSolde()));
       typeCompteField = new JTextField(compte.getTypeCompte());

       add(new JLabel("Numéro de Compte:"));
       add(numeroField);

       add(new JLabel("Solde:"));
       add(soldeField);

       add(new JLabel("Type de Compte:"));
       add(typeCompteField);

      JButton editButton = new JButton("Modifier");
      editButton.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
              compte.setSolde(Double.parseDouble(soldeField.getText()));
              compte.setTypeCompte(typeCompteField.getText());

              if (compteService.updateCompte(compte)) {
                  JOptionPane.showMessageDialog(EditCompteFrame.this, "Compte modifié avec succès !");
                  dispose();
              } else {
                  JOptionPane.showMessageDialog(EditCompteFrame.this, "Erreur lors de la modification du compte.", "Erreur", JOptionPane.ERROR_MESSAGE);
              }
          }
      });

      add(editButton);

      setSize(300, 200);
      setLocationRelativeTo(null); 
   }

    
}