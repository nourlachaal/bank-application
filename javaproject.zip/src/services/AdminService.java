package services;

public class AdminService {
    // Hardcoded credentials for admin
    private static final String ADMIN_NOM = "admin";
    private static final String ADMIN_PASSWORD = "admin";

    // Method to authenticate an admin
    public boolean authenticateAdmin(String nom, String password) {
        // Debugging output
        System.out.println("Trying to authenticate admin with nom: " + nom);
        
        // Check against hardcoded values
        return ADMIN_NOM.equals(nom) && ADMIN_PASSWORD.equals(password);
    }
}