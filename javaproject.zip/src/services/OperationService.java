package services;

import java.sql.*;

public class OperationService {
    private static final String URL = "\"C:\\Users\\User\\OneDrive\\Bureau\\JAVA\\resources\\database.db\"";

    // Method to perform a withdrawal
    public boolean withdraw(String accountNumber, double amount) {
        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "UPDATE comptes SET solde = solde - ? WHERE numero = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setDouble(1, amount);
            pstmt.setString(2, accountNumber);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to perform a deposit
    public boolean deposit(String accountNumber, double amount) {
        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "UPDATE comptes SET solde = solde + ? WHERE numero = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setDouble(1, amount);
            pstmt.setString(2, accountNumber);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to perform a transfer
    public boolean transfer(String sourceAccount, String destinationAccount, double amount) {
        try (Connection conn = DriverManager.getConnection(URL)) {
            conn.setAutoCommit(false); // Start a transaction
            boolean withdrawn = withdraw(sourceAccount, amount);
            boolean deposited = deposit(destinationAccount, amount);

            if (withdrawn && deposited) {
                conn.commit(); // Commit transaction
                return true;
            } else {
                conn.rollback(); // Rollback transaction if something fails
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
