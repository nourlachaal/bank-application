package services;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import models.Compte;

public class CompteService {
    private static final String URL = "jdbc:sqlite:C:\\Users\\User\\OneDrive\\Bureau\\JAVA\\resources\\database.db";

    // Method to add a new account
    public boolean addCompte(Compte compte) {
        String sql = "INSERT INTO comptes (numero, cin_proprietaire, solde, date_ouverture, type_compte) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, compte.getNumero());
            pstmt.setString(2, compte.getCinProprietaire());
            pstmt.setDouble(3, compte.getSolde());
            pstmt.setDate(4, new java.sql.Date(compte.getDateOuverture().getTime()));
            pstmt.setString(5, compte.getTypeCompte());
            return pstmt.executeUpdate() > 0; // Returns true if insertion was successful
        } catch (SQLException e) {
            e.printStackTrace(); // Print error for debugging
            return false; // Return false on error
        }
    }

    // Method to get all accounts from the database
    public List<Compte> getAllComptes() {
        List<Compte> comptes = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "SELECT * FROM comptes";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Compte compte = new Compte(
                        rs.getString("numero"),
                        rs.getString("cin_proprietaire"),
                        rs.getDouble("solde"),
                        rs.getDate("date_ouverture"),
                        rs.getString("type_compte")
                );
                comptes.add(compte);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return comptes;
    }

    // Method to update an existing account
    public boolean updateCompte(Compte compte) {
        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "UPDATE comptes SET solde = ?, type_compte = ? WHERE numero = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setDouble(1, compte.getSolde());
            pstmt.setString(2, compte.getTypeCompte());
            pstmt.setString(3, compte.getNumero()); // Ensure this is set correctly
            return pstmt.executeUpdate() > 0; // Returns true if update was successful
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to delete an account
    public boolean deleteCompte(String numero) {
        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "DELETE FROM comptes WHERE numero = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, numero);
            return pstmt.executeUpdate() > 0; // Returns true if deletion was successful
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to find an account by its number
    public Compte findCompteByNumero(String numero) {
        Compte compte = null;
        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "SELECT * FROM comptes WHERE numero = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, numero);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                compte = new Compte(
                        rs.getString("numero"),
                        rs.getString("cin_proprietaire"),
                        rs.getDouble("solde"),
                        rs.getDate("date_ouverture"),
                        rs.getString("type_compte"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return compte; // Returns the found account or null if not found
    }
}


