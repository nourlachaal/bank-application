package services;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import models.Client;

public class ClientService {
    private static final String URL = "jdbc:sqlite:C:\\Users\\User\\OneDrive\\Bureau\\JAVA\\resources\\database.db";

    public List<Client> getAllClients() {
        List<Client> clients = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "SELECT * FROM clients";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Client client = new Client(
                        rs.getString("cin"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        rs.getString("telephone"),
                        rs.getString("password"));
                clients.add(client);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clients;
    }

    public boolean addClient(Client client) {
        String sql = "INSERT INTO clients (cin, nom, prenom, telephone, password) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL);
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, client.getCin());
            pstmt.setString(2, client.getNom());
            pstmt.setString(3, client.getPrenom());
            pstmt.setString(4, client.getTelephone());
            pstmt.setString(5, client.getPassword());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteClient(String cin) {
        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "DELETE FROM clients WHERE cin = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, cin);

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateClient(Client client) {
        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "UPDATE clients SET nom=?, prenom=?, telephone=?, password=? WHERE cin=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, client.getNom());
            pstmt.setString(2, client.getPrenom());
            pstmt.setString(3, client.getTelephone());
            pstmt.setString(4, client.getPassword());
            pstmt.setString(5, client.getCin());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Client findClientByCin(String cin) {
        Client client = null;

        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "SELECT * FROM clients WHERE cin=?";

            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, cin);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                client = new Client(
                        rs.getString("cin"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        rs.getString("telephone"),
                        rs.getString("password"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return client;
    }

    private boolean authenticateClient(String cin, String nom) {
        ClientService clientService = new ClientService(); // Initialiser le service des clients
        Client client = clientService.findClientByCin(cin); // Trouver le client par CIN
        return client != null && client.getNom().equalsIgnoreCase(nom); // Vérifier si le nom correspond
    }

}
