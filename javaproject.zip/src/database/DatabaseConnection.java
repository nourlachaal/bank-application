package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // Path to your SQLite database file
    private static final String DB_URL = "jdbc:sqlite:C:\\Users\\User\\OneDrive\\Bureau\\JAVA\\resources\\database.db";

    // Method to connect to the database
    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }
}